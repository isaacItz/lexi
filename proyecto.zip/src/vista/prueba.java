package vista;

public class prueba {
	public static void main(String[] args) {
		int a=5;
		double b=10.5;
		System.out.println(a+b);
	}

}
